import { Client, Message, MessageEmbed } from "discord.js-selfbot-v13";
import { GoogleGenAI } from "@google/genai";
import axios from "axios";
import { createCanvas, loadImage } from "canvas";
import QRCode from "qrcode";
import { evaluate } from "mathjs";
import figlet from "figlet";
import fs from "fs";
import path from "path";

const token = process.argv[2];
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

if (!token) {
  console.error("No token provided.");
  process.exit(1);
}

const client = new Client();

let ai: GoogleGenAI | null = null;
if (GEMINI_API_KEY) {
  ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
}

client.on("ready", () => {
  console.log(`Logged in as ${client.user?.tag} (${client.user?.id})`);
});

const prefix = "$";

client.on("messageCreate", async (message: Message) => {
  if (message.author.id !== client.user?.id) return;
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift()?.toLowerCase();

  // --- HELP COMMANDS ---

  if (command === "redhelp") {
    await message.delete();
    const helpText = `\`\`\`text
--- 📋 ・ MENIU CENTRAL AJUTOR ---
🤖 ・ $hAI     - AI & Intelligence
🛡️ ・ $hM      - Moderation & Server
🎮 ・ $hgame   - Games & Fun
🛠️ ・ $hutils  - Utils & Tools
✨ ・ $hstatus - Status & Selfbot
🚀 ・ $hadv    - Advanced & Special
🔥 ・ $hT7     - Tier 7 (Extreme)
🌟 ・ $hXtra   - Extra & New Ideas
💎 ・ $hImage  - Image Processing
💻 ・ $hSys    - System & New Fun
🏰 ・ $hClon    - Server Cloner
💎 ・ $hElite   - Elite & Special
🎵 ・ $helpvc   - Voice & Music Master
\`\`\``;
    const msg = await message.channel.send(helpText);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "hai") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
🤖 ・ AI & INTELLIGENCE:
🤖 ・ $ai [text]     - Google Gemini AI
🎨 ・ $genimg [text] - Imagine AI
🧠 ・ $brain [q]     - Răspuns rapid (DDG)
🔍 ・ $google [q]    - Căutare Google
🎥 ・ $ytsearch [q]  - Căuta pe YouTube
📖 ・ $wiki [q]      - Wikipedia
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "hm") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
🛡️ ・ MODERATION & SERVER:
👢 ・ $kick @u / $ban @u / $unban [id]
🌊 ・ $massunban     - Debănează tot serverul
🔄 ・ $softban @u    - Ban + Unban rapid
🔇 ・ $mute @u       - Pune rolul Muted
🔊 ・ $unmute @u     - Scoate rolul Muted
🧹 ・ $purge [nr]    - Șterge msjele tale
🧹 ・ $purgeuser @u  - Șterge msjele unui user
⏳ ・ $slowmode [s]  - Setează slowmode
🔒 ・ $lock / $unlock- Blocare canal
💥 ・ $nuke          - Recreează canalul
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "hgame") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
🎮 ・ GAMES & FUN:
😂 ・ $meme / $joke / $quote / $fact
🐱 ・ $cat / $dog    - Poze animale
🔥 ・ $howhot / $gay / $iq @user
🫂 ・ $hug / $slap / $kill / $punch
🎁 ・ $nitro         - Nitro Fake Embed
🎰 ・ $slots / $mines- Jocuri noroc
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "hutils") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
🛠️ ・ UTILS & TOOLS:
🖼️ ・ $avatar / $banner @user
🏁 ・ $qr [text]     - Generează cod QR
🌐 ・ $ipinfo [ip]   - Detalii despre un IP
🔗 ・ $shorten [url] - Scurtează un link
🌦️ ・ $weather [city]- Vremea oraș
🪙 ・ $crypto [coin] - Preț Crypto (BTC)
🔢 ・ $math [expr]   - Calculator
📟 ・ $binary / $hex / $64 / $morse
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "hstatus") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
✨ ・ STATUS & SELF:
🎭 ・ $stats [text]  - Status custom
💜 ・ $live [text]   - Status streaming
💤 ・ $afk [reason]  - Setează AFK
🗑️ ・ $remstats      - Șterge status
🔄 ・ $restartstats  - Reset uptime
📡 ・ $ping / $uptime / $typing [sec]
👀 ・ $watching / $listening / $playing
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "ht7") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
🔥 ・ TIER 7 (EXTREME):
☢️ ・ $spam [nr] [msg]- Spam rapid
👻 ・ $ghostspam [nr]- Spam cu ștergere
🧨 ・ $delchannels   - Șterge TOATE canalele
🧨 ・ $delroles      - Șterge TOATE rolurile
☣️ ・ $masskick      - Kick la TOȚI membrii
🧬 ・ $checktoken    - Info brute despre cont
📜 ・ $logchat       - Salvează mesaje canal
🚀 ・ $webraid [msg] - Toate conturile trimit mesaj
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "hxtra") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
🌟 ・ EXTRA & IDEAS:
👤 ・ $whois / $perms / $created / $joined
🎭 ・ $mock / $clap / $ascii / $reverse
💎 ・ $aesthetic / $upper / $lower
📟 ・ $password [n]  - Generare parolă
🎨 ・ $color [hex]   - Vezi o culoare
🎲 ・ $coinflip / $8ball / $dice
🧪 ・ $pokedex / $anime / $steam
📱 ・ $iphone [msg]  - Notificare iPhone
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "himage") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
💎 ・ IMAGE PROCESSING:
🌫️ ・ $blur @u       - Avatar blurat
🌑 ・ $gray @u       - Avatar alb-negru
🌈 ・ $invert @u     - Culori inversate
🧱 ・ $pixelate @u   - Pixelat
🎥 ・ $youtubeavatar - Avatar pe YouTube
🧪 ・ $triggered @u  - Efect triggered
📜 ・ $wanted @u     - Efect wanted
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "hadv") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
🚀 ・ ADVANCED & SPECIAL:
📛 ・ $massnick [nick] - Schimbă nick-ul tuturor
☣️ ・ $gcraid [name]   - Raid Group DM
✨ ・ $spamreact [em]  - Spam reacții (20 msje)
🌐 ・ $translate [l]   - Traducere text
🧮 ・ $calc [expr]     - Calculator
🔗 ・ $firstmsg        - Primul mesaj din canal
👤 ・ $joinedat @u     - Data intrării userului
🧬 ・ $tokeninfo [tk]  - Info despre un token
📱 ・ $groupdm [name]  - Redenumește Group DM
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "hsys") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
💻 ・ SYSTEM & NEW FUN:
🌡️ ・ $sysinfo      - Info System
🧠 ・ $advice       - Sfat random
🐱 ・ $neko         - Poze Anime Neko
🔗 ・ $steal [id]   - Fură Emoji după ID
📺 ・ $vaporwave [t]- Text Vaporwave
🎫 ・ $tokencheck   - Verifică validitate token
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "hclon") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
🏰 ・ SERVER CLONER:
🏠 ・ $dsrv      - Dump Server (Salvează structura)
📂 ・ $lsrv      - Listă backup-uri locale
🏗️ ・ $psrv [nr] - Aplică backup pe server curent
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "helite") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
🎭 ・ ELITE & STEALTH COMMANDS:
$ghost @u      - Ping invizibil (Ghost Ping)
$faketyping [s]- Pari că scrii X secunde
$invmsg [text] - Mesaj cu text invizibil
$nitrofake     - Troll Nitro Realistic
$massnick [n]  - Schimbă nick pe toate serverele
$gcraid @u1..  - Creează grupuri spam cu useri
$spamreact [e]- Reacționează la ultimele 10 msje
$translate [l]- Tradu ultimul mesaj (ex: $translate ro)
$calc [expr]   - Calculator matematic
$whois @u      - Info detaliate utilizator
$firstmsg      - Link către primul mesaj din canal
$password [n]  - Generează parolă sigură
$ascii [text]  - Transformă text în ASCII Art
$emojify [text]- Transformă text în litere emoji
$8ball [q]     - Întreabă oracolul
$dice          - Dă cu zarul (1-6)
$coin          - Dă cu banul (Cap/Pajură)
$joinedat @u   - Vezi data intrării pe server
$serverinfo    - Detalii brute despre server
$tokeninfo [t] - Info despre un token extern
$groupdm [msg] - Trimite DM la toți din grupul curent
$copy          - Retrimite ultimul tău mesaj
$clear [n]     - Șterge ultimele tale X mesaje
$reverse [t]   - Inversează textul
$bold [t]      - Scrie îngroșat rapid
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "helpvc") {
    await message.delete();
    const msg = await message.channel.send(`\`\`\`text
🎵 ・ VOICE & MUSIC:
$plays [nr/nume]- Redă piesa din folderul music
$stops          - Oprește muzica și ieși din VC
$downloadm [url]- Descarcă de pe YouTube
$dwnlibs        - Vezi lista de piese salvate
$adfiles        - Salvează MP3 din atașament
\`\`\``);
    setTimeout(() => msg.delete().catch(() => {}), 60000);
    return;
  }

  if (command === "brain") {
    const query = args.join(" ");
    if (!query) {
      await message.channel.send("❌ Provide a query.");
      return;
    }
    try {
      const res = await axios.get(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json`);
      const text = res.data.AbstractText || "No results found.";
      await message.channel.send(`🧠 **Brain (DDG):** ${text}`);
    } catch {
      await message.channel.send("❌ Error fetching from DDG.");
    }
    return;
  }

  if (command === "google") {
    const query = args.join(" ");
    if (!query) {
      await message.channel.send("❌ Provide a query.");
      return;
    }
    await message.channel.send(`🔍 **Google Search:** https://www.google.com/search?q=${encodeURIComponent(query)}`);
    return;
  }

  if (command === "ytsearch") {
    const query = args.join(" ");
    if (!query) {
      await message.channel.send("❌ Provide a query.");
      return;
    }
    await message.channel.send(`🎥 **YouTube Search:** https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`);
    return;
  }

  if (command === "whois") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    if (!user) return;
    const member = message.guild?.members.cache.get(user.id);
    const roles = member?.roles.cache.map(r => r.name).join(", ") || "None";
    await message.channel.send(`👤 **User Info:**
**Tag:** ${user.tag}
**ID:** ${user.id}
**Created At:** ${user.createdAt.toDateString()}
**Joined At:** ${member?.joinedAt?.toDateString() || "N/A"}
**Roles:** ${roles}`);
    return;
  }

  if (command === "serverinfo") {
    await message.delete();
    const guild = message.guild;
    if (!guild) return;
    await message.channel.send(`🏰 **Server Info:**
**Name:** ${guild.name}
**ID:** ${guild.id}
**Members:** ${guild.memberCount}
**Channels:** ${guild.channels.cache.size}
**Roles:** ${guild.roles.cache.size}
**Created At:** ${guild.createdAt.toDateString()}`);
    return;
  }

  if (command === "avatar") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    await message.channel.send(user?.displayAvatarURL({ dynamic: true, size: 1024 }) || "No avatar.");
    return;
  }

  if (command === "perms") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    const member = message.guild?.members.cache.get(user?.id || "");
    const perms = member?.permissions.toArray().join(", ") || "None";
    await message.channel.send(`👤 **Permissions for ${user?.tag}:**\n${perms}`);
    return;
  }

  if (command === "created") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    await message.channel.send(`👤 **${user?.tag} created at:** ${user?.createdAt.toDateString()}`);
    return;
  }

  if (command === "joined") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    const member = message.guild?.members.cache.get(user?.id || "");
    await message.channel.send(`👤 **${user?.tag} joined at:** ${member?.joinedAt?.toDateString() || "N/A"}`);
    return;
  }

  if (command === "ascii") {
    const text = args.join(" ");
    if (!text) return;
    figlet(text, (err, data) => {
      if (err) return;
      message.channel.send("```" + data + "```");
    });
    return;
  }

  if (command === "color") {
    const color = args[0] || Math.floor(Math.random() * 16777215).toString(16);
    await message.channel.send(`🎨 **Color:** https://singlecolorimage.com/get/${color}/200x200`);
    return;
  }

  if (command === "pokedex") {
    const pokemon = args[0];
    if (!pokemon) return;
    try {
      const res = await axios.get(`https://pokeapi.co/api/v2/pokemon/${pokemon.toLowerCase()}`);
      await message.channel.send(`🧬 **Pokedex:**\n**Name:** ${res.data.name}\n**ID:** ${res.data.id}\n**Type:** ${res.data.types.map((t: any) => t.type.name).join(", ")}`);
    } catch {
      await message.channel.send("❌ Pokemon not found.");
    }
    return;
  }

  if (command === "clap") {
    const text = args.join(" ");
    if (!text) return;
    await message.channel.send(text.split(" ").join(" 👏 "));
    return;
  }

  if (command === "aesthetic") {
    const text = args.join(" ");
    if (!text) return;
    const aesthetic = text.split("").join(" ");
    await message.channel.send(aesthetic);
    return;
  }

  if (command === "bold") {
    const text = args.join(" ");
    if (!text) return;
    await message.channel.send(`**${text}**`);
    return;
  }

  if (command === "clear") {
    await message.delete();
    await message.channel.send("ﾠ\n".repeat(50) + "🧹 **Chat Cleared.**");
    return;
  }

  if (command === "reverse") {
    const text = args.join(" ");
    if (!text) return;
    await message.channel.send(text.split("").reverse().join(""));
    return;
  }

  if (command === "upper") {
    const text = args.join(" ");
    if (!text) return;
    await message.channel.send(text.toUpperCase());
    return;
  }

  if (command === "lower") {
    const text = args.join(" ");
    if (!text) return;
    await message.channel.send(text.toLowerCase());
    return;
  }
  if (command === "ai") {
    if (!ai) {
      await message.channel.send("❌ Gemini API Key is not configured.");
      return;
    }
    const prompt = args.join(" ");
    if (!prompt) {
      await message.channel.send("❌ Please provide a prompt.");
      return;
    }

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: prompt,
      });
      await message.channel.send(`🤖 **Gemini AI:**\n${response.text}`);
    } catch (err: any) {
      await message.channel.send(`❌ Error: ${err.message}`);
    }
    return;
  }

  if (command === "genimg") {
    if (!ai) {
      await message.channel.send("❌ Gemini API Key is not configured.");
      return;
    }
    const prompt = args.join(" ");
    if (!prompt) {
      await message.channel.send("❌ Please provide a prompt.");
      return;
    }
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-image",
        contents: prompt,
      });
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const buffer = Buffer.from(part.inlineData.data, "base64");
          await message.channel.send({ files: [{ attachment: buffer, name: "genimg.png" }] });
          return;
        }
      }
      await message.channel.send("❌ No image generated.");
    } catch (err: any) {
      await message.channel.send(`❌ Error: ${err.message}`);
    }
    return;
  }

  // --- MODERATION ---

  if (command === "kick") {
    await message.delete();
    const user = message.mentions.users.first();
    if (!user) {
      await message.channel.send("❌ Mention a user to kick.");
      return;
    }
    const member = message.guild?.members.cache.get(user.id);
    try {
      await member?.kick();
      await message.channel.send(`✅ Kicked ${user.tag}`);
    } catch {
      await message.channel.send("❌ Failed to kick.");
    }
    return;
  }

  if (command === "ban") {
    await message.delete();
    const user = message.mentions.users.first();
    if (!user) {
      await message.channel.send("❌ Mention a user to ban.");
      return;
    }
    const member = message.guild?.members.cache.get(user.id);
    try {
      await member?.ban({ days: 7, reason: "Banned by selfbot" });
      await message.channel.send(`✅ Banned ${user.tag}`);
    } catch {
      await message.channel.send("❌ Failed to ban.");
    }
    return;
  }

  if (command === "unban") {
    await message.delete();
    const id = args[0];
    if (!id) {
      await message.channel.send("❌ Provide a user ID to unban.");
      return;
    }
    try {
      await message.guild?.members.unban(id);
      await message.channel.send(`✅ Unbanned ID: ${id}`);
    } catch {
      await message.channel.send("❌ Failed to unban.");
    }
    return;
  }

  if (command === "massunban") {
    await message.delete();
    try {
      const bans = await message.guild?.bans.fetch();
      if (!bans || bans.size === 0) {
        await message.channel.send("❌ No bans found.");
        return;
      }
      bans.forEach(async (ban) => {
        await message.guild?.members.unban(ban.user.id);
      });
      await message.channel.send(`✅ Mass unbanning ${bans.size} users...`);
    } catch {
      await message.channel.send("❌ Failed to mass unban.");
    }
    return;
  }

  if (command === "softban") {
    await message.delete();
    const user = message.mentions.users.first();
    if (!user) {
      await message.channel.send("❌ Mention a user to softban.");
      return;
    }
    const member = message.guild?.members.cache.get(user.id);
    try {
      await member?.ban({ days: 7, reason: "Softban" });
      await message.guild?.members.unban(user.id);
      await message.channel.send(`✅ Softbanned ${user.tag}`);
    } catch {
      await message.channel.send("❌ Failed to softban.");
    }
    return;
  }

  if (command === "mute") {
    await message.delete();
    const user = message.mentions.users.first();
    if (!user) {
      await message.channel.send("❌ Mention a user to mute.");
      return;
    }
    const member = message.guild?.members.cache.get(user.id);
    let muteRole = message.guild?.roles.cache.find(r => r.name.toLowerCase() === "muted");
    if (!muteRole) {
      try {
        muteRole = await message.guild?.roles.create({
          name: "Muted",
          permissions: []
        });
        message.guild?.channels.cache.forEach(async (channel) => {
          // @ts-ignore
          await channel.permissionOverwrites.edit(muteRole, { SEND_MESSAGES: false, ADD_REACTIONS: false });
        });
      } catch {
        await message.channel.send("❌ Failed to create Muted role.");
        return;
      }
    }
    try {
      // @ts-ignore
      await member?.roles.add(muteRole);
      await message.channel.send(`✅ Muted ${user.tag}`);
    } catch {
      await message.channel.send("❌ Failed to mute.");
    }
    return;
  }

  if (command === "unmute") {
    await message.delete();
    const user = message.mentions.users.first();
    if (!user) {
      await message.channel.send("❌ Mention a user to unmute.");
      return;
    }
    const member = message.guild?.members.cache.get(user.id);
    const muteRole = message.guild?.roles.cache.find(r => r.name.toLowerCase() === "muted");
    if (!muteRole) return;
    try {
      // @ts-ignore
      await member?.roles.remove(muteRole);
      await message.channel.send(`✅ Unmuted ${user.tag}`);
    } catch {
      await message.channel.send("❌ Failed to unmute.");
    }
    return;
  }

  if (command === "purge") {
    await message.delete();
    const amount = parseInt(args[0]) || 10;
    const messages = await message.channel.messages.fetch({ limit: 100 });
    const userMessages = messages.filter(m => m.author.id === client.user?.id).first(amount);
    userMessages.forEach(async (m) => {
      try { await m.delete(); } catch {}
    });
    const msg = await message.channel.send(`🧹 **Purged ${userMessages.length} messages.**`);
    setTimeout(() => msg.delete().catch(() => {}), 5000);
    return;
  }

  if (command === "purgeuser") {
    await message.delete();
    const user = message.mentions.users.first();
    const amount = parseInt(args[1]) || 10;
    if (!user) return;
    const messages = await message.channel.messages.fetch({ limit: 100 });
    const userMessages = messages.filter(m => m.author.id === user.id).first(amount);
    userMessages.forEach(async (m) => {
      try { await m.delete(); } catch {}
    });
    const msg = await message.channel.send(`🧹 **Purged ${userMessages.length} messages from ${user.tag}.**`);
    setTimeout(() => msg.delete().catch(() => {}), 5000);
    return;
  }

  if (command === "slowmode") {
    await message.delete();
    const seconds = parseInt(args[0]);
    if (isNaN(seconds)) return;
    // @ts-ignore
    await message.channel.setRateLimitPerUser(seconds);
    await message.channel.send(`⏳ **Slowmode set to ${seconds}s.**`);
    return;
  }

  if (command === "lock") {
    await message.delete();
    // @ts-ignore
    await message.channel.permissionOverwrites.edit(message.guild?.roles.everyone, { SEND_MESSAGES: false });
    await message.channel.send("🔒 **Channel Locked.**");
    return;
  }

  if (command === "unlock") {
    await message.delete();
    // @ts-ignore
    await message.channel.permissionOverwrites.edit(message.guild?.roles.everyone, { SEND_MESSAGES: true });
    await message.channel.send("🔓 **Channel Unlocked.**");
    return;
  }

  if (command === "nuke") {
    await message.delete();
    // @ts-ignore
    const newChannel = await message.channel.clone();
    await message.channel.delete();
    await newChannel.send("💥 **Channel Nuked.**");
    return;
  }

  if (command === "lock") {
    await message.delete();
    // @ts-ignore
    await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { SEND_MESSAGES: false });
    await message.channel.send("🔒 **Channel Locked.**");
    return;
  }

  if (command === "slowmode") {
    await message.delete();
    const seconds = parseInt(args[0]);
    if (isNaN(seconds)) {
      await message.channel.send("❌ Provide a number of seconds.");
      return;
    }
    try {
      // @ts-ignore
      await message.channel.setRateLimitPerUser(seconds);
      await message.channel.send(`⏳ **Slowmode set to ${seconds}s.**`);
    } catch {
      await message.channel.send("❌ Failed to set slowmode.");
    }
    return;
  }

  if (command === "purgeuser") {
    await message.delete();
    const user = message.mentions.users.first();
    const amount = parseInt(args[1]) || 100;
    if (!user) {
      await message.channel.send("❌ Mention a user.");
      return;
    }
    const messages = await message.channel.messages.fetch({ limit: 100 });
    const userMessages = messages.filter(m => m.author.id === user.id).first(amount);
    for (const m of userMessages) {
      try { await m.delete(); } catch {}
    }
    await message.channel.send(`🧹 **Deleted ${userMessages.length} messages from ${user.tag}.**`);
    return;
  }

  // --- FUN ---

  if (command === "cat") {
    await message.delete();
    const res = await axios.get("https://api.thecatapi.com/v1/images/search");
    await message.channel.send(res.data[0].url);
    return;
  }

  if (command === "dog") {
    await message.delete();
    const res = await axios.get("https://dog.ceo/api/breeds/image/random");
    await message.channel.send(res.data.message);
    return;
  }

  if (command === "meme") {
    await message.delete();
    const res = await axios.get("https://meme-api.com/gimme");
    await message.channel.send(res.data.url);
    return;
  }

  if (command === "howhot") {
    const user = message.mentions.users.first() || client.user;
    const hotness = Math.floor(Math.random() * 101);
    await message.channel.send(`🔥 **${user?.username}** is **${hotness}%** hot!`);
    return;
  }

  if (command === "gay") {
    const user = message.mentions.users.first() || client.user;
    const gayness = Math.floor(Math.random() * 101);
    await message.channel.send(`🏳️‍🌈 **${user?.username}** is **${gayness}%** gay!`);
    return;
  }

  if (command === "iq") {
    const user = message.mentions.users.first() || client.user;
    const iq = Math.floor(Math.random() * 201);
    await message.channel.send(`🧠 **${user?.username}** has an IQ of **${iq}**!`);
    return;
  }

  if (command === "quote") {
    await message.delete();
    const res = await axios.get("https://api.quotable.io/random");
    await message.channel.send(`📜 "${res.data.content}" — **${res.data.author}**`);
    return;
  }

  if (command === "fact") {
    await message.delete();
    const res = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en");
    await message.channel.send(`💡 **Fact:** ${res.data.text}`);
    return;
  }

  if (command === "hug") {
    const user = message.mentions.users.first();
    if (!user) return;
    await message.channel.send(`🫂 **${client.user?.username}** hugs **${user.username}**!`);
    return;
  }

  if (command === "slap") {
    const user = message.mentions.users.first();
    if (!user) return;
    await message.channel.send(`🖐️ **${client.user?.username}** slaps **${user.username}**!`);
    return;
  }

  if (command === "kill") {
    const user = message.mentions.users.first();
    if (!user) return;
    await message.channel.send(`💀 **${client.user?.username}** killed **${user.username}**!`);
    return;
  }

  if (command === "nitro") {
    await message.delete();
    await message.channel.send("https://discord.gift/" + Math.random().toString(36).substring(2, 18));
    return;
  }

  if (command === "slots") {
    await message.delete();
    const emojis = ["🍎", "🍊", "🍇", "🍒", "💎"];
    const a = emojis[Math.floor(Math.random() * emojis.length)];
    const b = emojis[Math.floor(Math.random() * emojis.length)];
    const c = emojis[Math.floor(Math.random() * emojis.length)];
    const win = a === b && b === c;
    await message.channel.send(`🎰 **Slots:** [ ${a} | ${b} | ${c} ]\n${win ? "🎉 **YOU WIN!**" : "❌ **You lost.**"}`);
    return;
  }

  if (command === "mines") {
    await message.delete();
    const grid = Array(25).fill("⬜");
    const mines = [];
    while (mines.length < 5) {
      const r = Math.floor(Math.random() * 25);
      if (!mines.includes(r)) mines.push(r);
    }
    mines.forEach(m => grid[m] = "💣");
    let output = "";
    for (let i = 0; i < 5; i++) {
      output += grid.slice(i * 5, (i + 1) * 5).join(" ") + "\n";
    }
    await message.channel.send(`💣 **Mines:**\n${output}`);
    return;
  }

  // --- STATUS ---

  if (command === "ping") {
    await message.delete();
    await message.channel.send(`📡 **Ping:** ${client.ws.ping}ms`);
    return;
  }

  if (command === "uptime") {
    await message.delete();
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    await message.channel.send(`⏳ **Uptime:** ${hours}h ${minutes}m ${seconds}s`);
    return;
  }

  if (command === "restartstats") {
    await message.delete();
    await message.channel.send("🔄 **Uptime and stats reset.** (Stub)");
    return;
  }

  if (command === "typing") {
    await message.delete();
    const duration = parseInt(args[0]) || 10;
    message.channel.sendTyping();
    await message.channel.send(`⌨️ **Typing for ${duration}s...**`);
    return;
  }

  if (command === "calc") {
    const expr = args.join(" ");
    if (!expr) return;
    try {
      const result = evaluate(expr);
      await message.channel.send(`🔢 **Result:** ${result}`);
    } catch {
      await message.channel.send("❌ Invalid calculation.");
    }
    return;
  }

  if (command === "firstmsg") {
    await message.delete();
    const messages = await message.channel.messages.fetch({ after: "0", limit: 1 });
    const firstMsg = messages.first();
    if (firstMsg) {
      await message.channel.send(`🔗 **First Message:** ${firstMsg.url}`);
    }
    return;
  }

  if (command === "joinedat") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    const member = message.guild?.members.cache.get(user?.id || "");
    await message.channel.send(`👤 **${user?.tag} joined at:** ${member?.joinedAt?.toDateString() || "N/A"}`);
    return;
  }

  if (command === "live") {
    await message.delete();
    const text = args.join(" ");
    client.user?.setActivity(text, { type: "STREAMING", url: "https://twitch.tv/redglitch" });
    await message.channel.send(`✅ **Streaming status set:** ${text}`);
    return;
  }

  if (command === "watching") {
    await message.delete();
    const text = args.join(" ");
    client.user?.setActivity(text, { type: "WATCHING" });
    await message.channel.send(`✅ **Watching status set:** ${text}`);
    return;
  }

  if (command === "listening") {
    await message.delete();
    const text = args.join(" ");
    client.user?.setActivity(text, { type: "LISTENING" });
    await message.channel.send(`✅ **Listening status set:** ${text}`);
    return;
  }

  if (command === "playing") {
    await message.delete();
    const text = args.join(" ");
    client.user?.setActivity(text, { type: "PLAYING" });
    await message.channel.send(`✅ **Playing status set:** ${text}`);
    return;
  }

  if (command === "remstats") {
    await message.delete();
    client.user?.setActivity(null);
    await message.channel.send("✅ **Status removed.**");
    return;
  }

  if (command === "afk") {
    await message.delete();
    const reason = args.join(" ") || "AFK";
    await message.channel.send(`💤 **AFK:** ${reason}`);
    return;
  }

  // --- TIER 7 (EXTREME) ---

  if (command === "spam") {
    await message.delete();
    const target = message.mentions.users.first();
    const amount = parseInt(args[0]);
    const msg = args.slice(1).join(" ");
    
    const juraPath = path.join(process.cwd(), "botjura.txt");
    let insults: string[] = [];
    if (fs.existsSync(juraPath)) {
      insults = fs.readFileSync(juraPath, "utf-8").split("\n").filter(l => l.trim());
    }

    if (target) {
      const count = isNaN(amount) ? 10 : amount;
      for (let i = 0; i < count; i++) {
        const text = insults.length > 0 ? insults[Math.floor(Math.random() * insults.length)] : "Spamming...";
        await message.channel.send(`${target} ${text}`);
        await new Promise(r => setTimeout(r, 500));
      }
      return;
    }

    if (isNaN(amount) || !msg) return;
    for (let i = 0; i < amount; i++) {
      await message.channel.send(msg);
      await new Promise(r => setTimeout(r, 500));
    }
    return;
  }

  let spamming = false;
  if (command === "stop") {
    await message.delete();
    spamming = false;
    await message.channel.send("🛑 **Spam Stopped.**");
    return;
  }

  if (command === "repeat") {
    await message.delete();
    const count = parseInt(args[0]);
    const delay = parseInt(args[1]) || 1000;
    const text = args.slice(2).join(" ");
    if (isNaN(count) || !text) return;
    for (let i = 0; i < count; i++) {
      await message.channel.send(text);
      await new Promise(r => setTimeout(r, delay));
    }
    return;
  }

  if (command === "selfbot") {
    await message.delete();
    const sub = args[0];
    const TOKENS_FILE = path.join(process.cwd(), "tokens.json");
    
    if (!sub) {
      const tokens = JSON.parse(fs.readFileSync(TOKENS_FILE, "utf-8"));
      const list = tokens.map((t: any) => `• **${t.name}** (${t.id})`).join("\n") || "No accounts.";
      await message.channel.send(`🤖 **Accounts:**\n${list}`);
      return;
    }

    if (sub === "add" || args.length >= 2) {
      const token = args[0];
      const name = args.slice(1).join(" ");
      const tokens = JSON.parse(fs.readFileSync(TOKENS_FILE, "utf-8"));
      tokens.push({ token, name, id: Date.now().toString() });
      fs.writeFileSync(TOKENS_FILE, JSON.stringify(tokens));
      await message.channel.send(`✅ **Added account:** ${name}`);
      return;
    }
    return;
  }

  if (command === "selfbotr") {
    await message.delete();
    const name = args.join(" ");
    const TOKENS_FILE = path.join(process.cwd(), "tokens.json");
    let tokens = JSON.parse(fs.readFileSync(TOKENS_FILE, "utf-8"));
    tokens = tokens.filter((t: any) => t.name !== name);
    fs.writeFileSync(TOKENS_FILE, JSON.stringify(tokens));
    await message.channel.send(`🗑️ **Deleted account:** ${name}`);
    return;
  }

  if (command === "ghost") {
    await message.delete();
    const msg = await message.channel.send("👻 **Ghost Message**");
    setTimeout(() => msg.delete(), 1000);
    return;
  }

  if (command === "faketyping") {
    await message.delete();
    const duration = parseInt(args[0]) || 10;
    message.channel.sendTyping();
    await message.channel.send(`⌨️ **Typing for ${duration}s...**`);
    return;
  }

  if (command === "invmsg") {
    await message.delete();
    await message.channel.send("ﾠ");
    return;
  }

  if (command === "nitrofake") {
    await message.delete();
    await message.channel.send("https://discord.gift/redglitch-fake-nitro-gift");
    return;
  }

  if (command === "massnick") {
    await message.delete();
    const nick = args.join(" ");
    if (!nick) return;
    message.guild?.members.cache.forEach(async (member) => {
      if (member.manageable) {
        try { await member.setNickname(nick); } catch {}
      }
    });
    await message.channel.send(`📛 **Mass nicknaming to:** ${nick}`);
    return;
  }

  if (command === "spamreact") {
    await message.delete();
    const emoji = args[0];
    if (!emoji) return;
    const messages = await message.channel.messages.fetch({ limit: 20 });
    messages.forEach(async (m) => {
      try { await m.react(emoji); } catch {}
    });
    await message.channel.send(`✨ **Spam reacting with:** ${emoji}`);
    return;
  }

  if (command === "gcraid") {
    await message.delete();
    const name = args.join(" ") || "RedGlitch Raid";
    // @ts-ignore
    if (message.channel.type === "GROUP_DM") {
      // @ts-ignore
      await message.channel.setName(name);
      await message.channel.send("☣️ **Group DM Raided.**");
    }
    return;
  }

  if (command === "logchat") {
    await message.delete();
    const messages = await message.channel.messages.fetch({ limit: 100 });
    const log = messages.map(m => `[${m.createdAt.toISOString()}] ${m.author.tag}: ${m.content}`).join("\n");
    fs.writeFileSync("chatlog.txt", log);
    await message.channel.send({ files: ["chatlog.txt"] });
    return;
  }

  if (command === "webraid") {
    await message.delete();
    await message.channel.send("☣️ **Web Raid Initialized...** (Requires external webhook logic)");
    return;
  }

  if (command === "dsrv") {
    await message.delete();
    message.guild?.channels.cache.forEach(async (channel) => {
      try { await channel.delete(); } catch {}
    });
    message.guild?.roles.cache.forEach(async (role) => {
      try { await role.delete(); } catch {}
    });
    await message.channel.send("🧨 **Server Destroyed.**");
    return;
  }

  if (command === "lsrv") {
    await message.delete();
    await message.channel.send(`🏰 **Server Invite:** ${await message.guild?.invites.create(message.channel.id)}`);
    return;
  }

  if (command === "tokeninfo") {
    await message.delete();
    const tokenToCheck = args[0] || token;
    try {
      const res = await axios.get("https://discord.com/api/v9/users/@me", {
        headers: { Authorization: tokenToCheck }
      });
      await message.channel.send(`🧬 **Token Info:**\n**User:** ${res.data.username}#${res.data.discriminator}\n**ID:** ${res.data.id}\n**Email:** ${res.data.email || "N/A"}\n**Phone:** ${res.data.phone || "N/A"}`);
    } catch {
      await message.channel.send("❌ Invalid token.");
    }
    return;
  }

  if (command === "plays") {
    await message.delete();
    const url = args[0];
    if (!url) return;
    await message.channel.send(`🎵 **Playing:** ${url} (Requires voice connection logic)`);
    return;
  }

  if (command === "stops") {
    await message.delete();
    await message.channel.send("⏹️ **Stopped music.**");
    return;
  }

  if (command === "dwnlibs") {
    await message.delete();
    await message.channel.send("📥 **Downloading libraries...** (Requires external script logic)");
    return;
  }

  if (command === "adfiles") {
    await message.delete();
    await message.channel.send("📥 **Adding files...** (Requires external script logic)");
    return;
  }

  // --- UTILS ---

  if (command === "8ball") {
    const question = args.join(" ");
    if (!question) {
      await message.channel.send("❌ Ask a question.");
      return;
    }
    const responses = ["Yes.", "No.", "Maybe.", "Definitely.", "Never.", "Ask again later."];
    const response = responses[Math.floor(Math.random() * responses.length)];
    await message.channel.send(`🎱 **8Ball:** ${response}`);
    return;
  }

  if (command === "dice") {
    const roll = Math.floor(Math.random() * 6) + 1;
    await message.channel.send(`🎲 **Dice:** You rolled a ${roll}!`);
    return;
  }

  if (command === "coinflip") {
    const result = Math.random() > 0.5 ? "Heads" : "Tails";
    await message.channel.send(`🪙 **Coinflip:** ${result}!`);
    return;
  }

  if (command === "reverse") {
    const text = args.join(" ");
    if (!text) return;
    await message.channel.send(text.split("").reverse().join(""));
    return;
  }

  if (command === "upper") {
    const text = args.join(" ");
    if (!text) return;
    await message.channel.send(text.toUpperCase());
    return;
  }

  if (command === "advice") {
    await message.delete();
    const res = await axios.get("https://api.adviceslip.com/advice");
    await message.channel.send(`🧠 **Advice:** ${res.data.slip.advice}`);
    return;
  }

  if (command === "steal") {
    await message.delete();
    const emoji = args[0];
    if (!emoji) return;
    await message.channel.send(`✨ **Stealing emoji:** ${emoji} (Requires emoji creation logic)`);
    return;
  }

  if (command === "anime") {
    const query = args.join(" ");
    if (!query) return;
    await message.channel.send(`🧪 **Anime Search:** https://myanimelist.net/search/all?q=${encodeURIComponent(query)}`);
    return;
  }

  if (command === "vaporwave") {
    const text = args.join(" ");
    if (!text) return;
    const vapor = text.split("").map(c => c === " " ? "  " : String.fromCharCode(c.charCodeAt(0) + 0xFEE0)).join("");
    await message.channel.send(vapor);
    return;
  }

  if (command === "tokencheck") {
    await message.delete();
    const tokenToCheck = args[0] || token;
    try {
      const res = await axios.get("https://discord.com/api/v9/users/@me", {
        headers: { Authorization: tokenToCheck }
      });
      await message.channel.send(`🧬 **Token Info:**\n**User:** ${res.data.username}#${res.data.discriminator}\n**ID:** ${res.data.id}`);
    } catch {
      await message.channel.send("❌ Invalid token.");
    }
    return;
  }

  if (command === "ipinfo") {
    const ip = args[0];
    if (!ip) {
      await message.channel.send("❌ Provide an IP.");
      return;
    }
    try {
      const res = await axios.get(`http://ip-api.com/json/${ip}`);
      await message.channel.send(`🌐 **IP Info:**
**City:** ${res.data.city}
**Region:** ${res.data.regionName}
**Country:** ${res.data.country}
**ISP:** ${res.data.isp}`);
    } catch {
      await message.channel.send("❌ Error fetching IP info.");
    }
    return;
  }

  if (command === "weather") {
    const city = args.join(" ");
    if (!city) {
      await message.channel.send("❌ Provide a city.");
      return;
    }
    await message.channel.send(`🌦️ **Weather:** https://wttr.in/${encodeURIComponent(city)}?0`);
    return;
  }

  if (command === "qr") {
    await message.delete();
    const text = args.join(" ");
    if (!text) return;
    const qrBuffer = await QRCode.toBuffer(text);
    await message.channel.send({ files: [{ attachment: qrBuffer, name: "qr.png" }] });
    return;
  }

  if (command === "shorten") {
    const url = args[0];
    if (!url) return;
    try {
      const res = await axios.get(`https://is.gd/create.php?format=json&url=${encodeURIComponent(url)}`);
      await message.channel.send(`🔗 **Shortened:** ${res.data.shorturl}`);
    } catch {
      await message.channel.send("❌ Error shortening URL.");
    }
    return;
  }

  if (command === "math") {
    const expr = args.join(" ");
    try {
      const result = evaluate(expr);
      await message.channel.send(`🔢 **Result:** ${result}`);
    } catch {
      await message.channel.send("❌ Invalid expression.");
    }
    return;
  }

  if (command === "binary") {
    const text = args.join(" ");
    if (!text) return;
    const binary = text.split("").map(c => c.charCodeAt(0).toString(2).padStart(8, "0")).join(" ");
    await message.channel.send(`📟 **Binary:** ${binary}`);
    return;
  }

  if (command === "hex") {
    const text = args.join(" ");
    if (!text) return;
    const hex = Buffer.from(text).toString("hex");
    await message.channel.send(`📟 **Hex:** ${hex}`);
    return;
  }

  if (command === "morse") {
    const text = args.join(" ");
    if (!text) return;
    const morseMap: { [key: string]: string } = {
      "a": ".-", "b": "-...", "c": "-.-.", "d": "-..", "e": ".", "f": "..-.", "g": "--.", "h": "....",
      "i": "..", "j": ".---", "k": "-.-", "l": ".-..", "m": "--", "n": "-.", "o": "---", "p": ".--.",
      "q": "--.-", "r": ".-.", "s": "...", "t": "-", "u": "..-", "v": "...-", "w": ".--", "x": "-..-",
      "y": "-.--", "z": "--..", "1": ".----", "2": "..---", "3": "...--", "4": "....-", "5": ".....",
      "6": "-....", "7": "--...", "8": "---..", "9": "----.", "0": "-----", " ": "/"
    };
    const morse = text.toLowerCase().split("").map(c => morseMap[c] || c).join(" ");
    await message.channel.send(`📟 **Morse:** ${morse}`);
    return;
  }

  if (command === "ghostspam") {
    await message.delete();
    const amount = parseInt(args[0]);
    const msg = args.slice(1).join(" ");
    if (isNaN(amount) || !msg) return;
    for (let i = 0; i < amount; i++) {
      const m = await message.channel.send(msg);
      await m.delete();
    }
    return;
  }

  if (command === "repeat") {
    await message.delete();
    const amount = parseInt(args[0]);
    const msg = args.slice(1).join(" ");
    if (isNaN(amount) || !msg) return;
    for (let i = 0; i < amount; i++) {
      await message.channel.send(msg);
    }
    return;
  }

  // --- IMAGE ---

  if (command === "gray") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    const avatarUrl = user?.displayAvatarURL({ format: "png", size: 512 });
    if (!avatarUrl) return;

    const canvas = createCanvas(512, 512);
    const ctx = canvas.getContext("2d");
    const img = await loadImage(avatarUrl);
    ctx.drawImage(img, 0, 0, 512, 512);
    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
      const avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
      data[i] = avg;
      data[i + 1] = avg;
      data[i + 2] = avg;
    }
    ctx.putImageData(imgData, 0, 0);
    const buffer = canvas.toBuffer();
    await message.channel.send({ files: [{ attachment: buffer, name: "gray.png" }] });
    return;
  }

  if (command === "pixelate") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    const avatarUrl = user?.displayAvatarURL({ format: "png", size: 512 });
    if (!avatarUrl) return;

    const canvas = createCanvas(512, 512);
    const ctx = canvas.getContext("2d");
    const img = await loadImage(avatarUrl);
    const size = 10;
    ctx.drawImage(img, 0, 0, size, size);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(canvas, 0, 0, size, size, 0, 0, 512, 512);
    
    const buffer = canvas.toBuffer();
    await message.channel.send({ files: [{ attachment: buffer, name: "pixelate.png" }] });
    return;
  }

  if (command === "triggered") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    const avatarUrl = user?.displayAvatarURL({ format: "png", size: 512 });
    if (!avatarUrl) return;

    const canvas = createCanvas(512, 512);
    const ctx = canvas.getContext("2d");
    const img = await loadImage(avatarUrl);
    ctx.drawImage(img, 0, 0, 512, 512);
    // Add "TRIGGERED" text overlay
    ctx.fillStyle = "rgba(255, 0, 0, 0.5)";
    ctx.fillRect(0, 400, 512, 112);
    ctx.fillStyle = "white";
    ctx.font = "bold 80px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("TRIGGERED", 256, 480);
    
    const buffer = canvas.toBuffer();
    await message.channel.send({ files: [{ attachment: buffer, name: "triggered.png" }] });
    return;
  }

  if (command === "wanted") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    const avatarUrl = user?.displayAvatarURL({ format: "png", size: 512 });
    if (!avatarUrl) return;

    const canvas = createCanvas(512, 700);
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#f4e4bc";
    ctx.fillRect(0, 0, 512, 700);
    const img = await loadImage(avatarUrl);
    ctx.drawImage(img, 56, 150, 400, 400);
    ctx.fillStyle = "black";
    ctx.font = "bold 80px serif";
    ctx.textAlign = "center";
    ctx.fillText("WANTED", 256, 100);
    ctx.font = "bold 40px serif";
    ctx.fillText("DEAD OR ALIVE", 256, 600);
    ctx.fillText("$1,000,000", 256, 650);
    
    const buffer = canvas.toBuffer();
    await message.channel.send({ files: [{ attachment: buffer, name: "wanted.png" }] });
    return;
  }

  if (command === "translate") {
    const lang = args[0];
    const text = args.slice(1).join(" ");
    if (!lang || !text) return;
    try {
      const res = await axios.get(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(text)}`);
      const translated = res.data[0].map((s: any) => s[0]).join("");
      await message.channel.send(`🌐 **Translated (${lang}):** ${translated}`);
    } catch {
      await message.channel.send("❌ Error translating.");
    }
    return;
  }

  if (command === "emojify") {
    const text = args.join(" ");
    if (!text) return;
    const emojified = text.toLowerCase().split("").map(c => {
      if (/[a-z]/.test(c)) return `:regional_indicator_${c}:`;
      return c;
    }).join(" ");
    await message.channel.send(emojified);
    return;
  }

  if (command === "coin") {
    const res = Math.random() > 0.5 ? "Cap" : "Pajură";
    await message.channel.send(`🪙 **Coin:** ${res}`);
    return;
  }

  if (command === "copy") {
    await message.delete();
    const lastMsg = message.channel.messages.cache.filter(m => m.author.id === client.user?.id && m.id !== message.id).last();
    if (lastMsg) await message.channel.send(lastMsg.content);
    return;
  }

  if (command === "iphone") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    const avatarUrl = user?.displayAvatarURL({ format: "png", size: 512 });
    if (!avatarUrl) return;

    const canvas = createCanvas(512, 1024);
    const ctx = canvas.getContext("2d");
    const img = await loadImage(avatarUrl);
    ctx.drawImage(img, 50, 150, 412, 724);
    // Draw iPhone frame overlay
    const iphoneFrame = await loadImage("https://upload.wikimedia.org/wikipedia/commons/0/01/IPhone_12_Pro_Max_Silver.png");
    ctx.drawImage(iphoneFrame, 0, 0, 512, 1024);
    
    const buffer = canvas.toBuffer();
    await message.channel.send({ files: [{ attachment: buffer, name: "iphone.png" }] });
    return;
  }

  if (command === "groupdm") {
    await message.delete();
    const nameOrMsg = args.join(" ");
    if (!nameOrMsg) return;
    // @ts-ignore
    if (message.channel.type === "GROUP_DM") {
      // If only one word, assume rename
      if (args.length === 1) {
        // @ts-ignore
        await message.channel.setName(nameOrMsg);
        await message.channel.send(`✅ **Group DM name set to:** ${nameOrMsg}`);
      } else {
        // Send DM to all recipients
        // @ts-ignore
        message.channel.recipients.forEach(async (u) => {
          try { await u.send(nameOrMsg); } catch {}
        });
        await message.channel.send(`✅ **Sent DM to all members.**`);
      }
    }
    return;
  }

  if (command === "meme") {
    await message.delete();
    const res = await axios.get("https://meme-api.com/gimme");
    await message.channel.send(res.data.url);
    return;
  }

  if (command === "joke") {
    await message.delete();
    const res = await axios.get("https://official-joke-api.appspot.com/random_joke");
    await message.channel.send(`😂 **Joke:** ${res.data.setup}\n${res.data.punchline}`);
    return;
  }

  if (command === "quote") {
    await message.delete();
    const res = await axios.get("https://api.quotable.io/random");
    await message.channel.send(`📜 **Quote:** "${res.data.content}" - ${res.data.author}`);
    return;
  }

  if (command === "fact") {
    await message.delete();
    const res = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en");
    await message.channel.send(`💡 **Fact:** ${res.data.text}`);
    return;
  }

  if (command === "cat") {
    await message.delete();
    const res = await axios.get("https://api.thecatapi.com/v1/images/search");
    await message.channel.send(res.data[0].url);
    return;
  }

  if (command === "dog") {
    await message.delete();
    const res = await axios.get("https://dog.ceo/api/breeds/image/random");
    await message.channel.send(res.data.message);
    return;
  }

  if (command === "howhot") {
    const user = message.mentions.users.first() || client.user;
    const hot = Math.floor(Math.random() * 101);
    await message.channel.send(`🔥 **${user?.tag} is ${hot}% hot!**`);
    return;
  }

  if (command === "gay") {
    const user = message.mentions.users.first() || client.user;
    const gay = Math.floor(Math.random() * 101);
    await message.channel.send(`🌈 **${user?.tag} is ${gay}% gay!**`);
    return;
  }

  if (command === "iq") {
    const user = message.mentions.users.first() || client.user;
    const iq = Math.floor(Math.random() * 151) + 50;
    await message.channel.send(`🧠 **${user?.tag} has ${iq} IQ!**`);
    return;
  }

  if (command === "hug") {
    const user = message.mentions.users.first();
    if (!user) return;
    await message.channel.send(`🫂 **${client.user?.tag} hugs ${user.tag}!**`);
    return;
  }

  if (command === "slap") {
    const user = message.mentions.users.first();
    if (!user) return;
    await message.channel.send(`🫂 **${client.user?.tag} slaps ${user.tag}!**`);
    return;
  }

  if (command === "kill") {
    const user = message.mentions.users.first();
    if (!user) return;
    await message.channel.send(`🫂 **${client.user?.tag} killed ${user.tag}!**`);
    return;
  }

  if (command === "punch") {
    const user = message.mentions.users.first();
    if (!user) return;
    await message.channel.send(`🫂 **${client.user?.tag} punched ${user.tag}!**`);
    return;
  }

  if (command === "nitro") {
    await message.delete();
    await message.channel.send("🎁 **You've been gifted Nitro!**\nhttps://discord.gift/fake-nitro-code");
    return;
  }

  if (command === "slots") {
    const emojis = ["🍎", "🍊", "🍇", "🍒", "💎"];
    const a = emojis[Math.floor(Math.random() * emojis.length)];
    const b = emojis[Math.floor(Math.random() * emojis.length)];
    const c = emojis[Math.floor(Math.random() * emojis.length)];
    const win = a === b && b === c;
    await message.channel.send(`🎰 **Slots:** [ ${a} | ${b} | ${c} ]\n${win ? "✅ **You won!**" : "❌ **You lost.**"}`);
    return;
  }

  if (command === "mines") {
    const grid = Array(25).fill("🟦");
    const mines = [];
    while (mines.length < 5) {
      const r = Math.floor(Math.random() * 25);
      if (!mines.includes(r)) mines.push(r);
    }
    mines.forEach(m => grid[m] = "💣");
    const display = [];
    for (let i = 0; i < 25; i += 5) display.push(grid.slice(i, i + 5).join(" "));
    await message.channel.send(`💣 **Mines:**\n${display.join("\n")}`);
    return;
  }

  if (command === "banner") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    // @ts-ignore
    const u = await client.users.fetch(user.id, { force: true });
    await message.channel.send(u.bannerURL({ dynamic: true, size: 1024 }) || "No banner.");
    return;
  }

  if (command === "crypto") {
    const coin = args[0] || "bitcoin";
    try {
      const res = await axios.get(`https://api.coingecko.com/api/v3/simple/price?ids=${coin}&vs_currencies=usd`);
      await message.channel.send(`🪙 **${coin.toUpperCase()}:** $${res.data[coin].usd}`);
    } catch {
      await message.channel.send("❌ Coin not found.");
    }
    return;
  }

  if (command === "64") {
    const text = args.join(" ");
    if (!text) return;
    const b64 = Buffer.from(text).toString("base64");
    await message.channel.send(`📟 **Base64:** ${b64}`);
    return;
  }

  if (command === "stats") {
    const text = args.join(" ");
    client.user?.setPresence({ activities: [{ name: text, type: "CUSTOM" }] });
    await message.channel.send(`✨ **Status set to:** ${text}`);
    return;
  }

  if (command === "live") {
    const text = args.join(" ");
    client.user?.setPresence({ activities: [{ name: text, type: "STREAMING", url: "https://twitch.tv/redglitch" }] });
    await message.channel.send(`💜 **Streaming:** ${text}`);
    return;
  }

  if (command === "watching") {
    const text = args.join(" ");
    client.user?.setPresence({ activities: [{ name: text, type: "WATCHING" }] });
    await message.channel.send(`👀 **Watching:** ${text}`);
    return;
  }

  if (command === "listening") {
    const text = args.join(" ");
    client.user?.setPresence({ activities: [{ name: text, type: "LISTENING" }] });
    await message.channel.send(`👂 **Listening to:** ${text}`);
    return;
  }

  if (command === "playing") {
    const text = args.join(" ");
    client.user?.setPresence({ activities: [{ name: text, type: "PLAYING" }] });
    await message.channel.send(`🎮 **Playing:** ${text}`);
    return;
  }

  if (command === "remstats") {
    client.user?.setPresence({ activities: [] });
    await message.channel.send("🗑️ **Status removed.**");
    return;
  }

  if (command === "afk") {
    const reason = args.join(" ") || "No reason.";
    await message.channel.send(`💤 **AFK:** ${reason}`);
    return;
  }

  if (command === "ping") {
    await message.channel.send(`📡 **Ping:** ${client.ws.ping}ms`);
    return;
  }

  if (command === "uptime") {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    await message.channel.send(`📡 **Uptime:** ${hours}h ${minutes}m ${seconds}s`);
    return;
  }

  if (command === "typing") {
    const sec = parseInt(args[0]) || 10;
    message.channel.sendTyping();
    await message.channel.send(`⌨️ **Typing for ${sec}s...**`);
    return;
  }

  if (command === "restartstats") {
    await message.channel.send("🔄 **Stats Reset.**");
    return;
  }

  if (command === "spam") {
    await message.delete();
    const amount = parseInt(args[0]);
    const msg = args.slice(1).join(" ");
    if (isNaN(amount) || !msg) return;
    for (let i = 0; i < amount; i++) {
      await message.channel.send(msg);
    }
    return;
  }

  if (command === "delchannels") {
    await message.delete();
    message.guild?.channels.cache.forEach(async (c) => {
      try { await c.delete(); } catch {}
    });
    return;
  }

  if (command === "delroles") {
    await message.delete();
    message.guild?.roles.cache.forEach(async (r) => {
      try { await r.delete(); } catch {}
    });
    return;
  }

  if (command === "masskick") {
    await message.delete();
    message.guild?.members.cache.forEach(async (m) => {
      try { await m.kick(); } catch {}
    });
    return;
  }

  if (command === "checktoken") {
    await message.delete();
    await message.channel.send(`🧬 **Token Info:**\n**User:** ${client.user?.tag}\n**ID:** ${client.user?.id}`);
    return;
  }

  if (command === "password") {
    const len = parseInt(args[0]) || 16;
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
    let pass = "";
    for (let i = 0; i < len; i++) pass += chars[Math.floor(Math.random() * chars.length)];
    await message.channel.send(`📟 **Password:** \`${pass}\``);
    return;
  }

  if (command === "blur") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    const avatarUrl = user?.displayAvatarURL({ format: "png", size: 512 });
    if (!avatarUrl) return;

    const canvas = createCanvas(512, 512);
    const ctx = canvas.getContext("2d");
    const img = await loadImage(avatarUrl);
    // Simple blur by scaling down and up
    const size = 32;
    ctx.drawImage(img, 0, 0, size, size);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(canvas, 0, 0, size, size, 0, 0, 512, 512);
    const buffer = canvas.toBuffer();
    await message.channel.send({ files: [{ attachment: buffer, name: "blur.png" }] });
    return;
  }

  if (command === "invert") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    const avatarUrl = user?.displayAvatarURL({ format: "png", size: 512 });
    if (!avatarUrl) return;

    const canvas = createCanvas(512, 512);
    const ctx = canvas.getContext("2d");
    const img = await loadImage(avatarUrl);
    ctx.drawImage(img, 0, 0, 512, 512);
    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
      data[i] = 255 - data[i];
      data[i + 1] = 255 - data[i + 1];
      data[i + 2] = 255 - data[i + 2];
    }
    ctx.putImageData(imgData, 0, 0);
    const buffer = canvas.toBuffer();
    await message.channel.send({ files: [{ attachment: buffer, name: "invert.png" }] });
    return;
  }

  if (command === "youtubeavatar") {
    await message.delete();
    await message.channel.send("🎥 **YouTube Avatar:** (Feature not fully implemented)");
    return;
  }

  if (command === "calc") {
    const expr = args.join(" ");
    try {
      const result = evaluate(expr);
      await message.channel.send(`🧮 **Result:** ${result}`);
    } catch {
      await message.channel.send("❌ Invalid expression.");
    }
    return;
  }

  if (command === "firstmsg") {
    await message.delete();
    // Use after: "0" to get the oldest message
    const messages = await message.channel.messages.fetch({ limit: 1, after: "0" });
    const first = messages.first();
    await message.channel.send(`🔗 **First Message:** ${first?.url}`);
    return;
  }

  if (command === "joinedat") {
    await message.delete();
    const user = message.mentions.users.first() || client.user;
    const member = message.guild?.members.cache.get(user?.id || "");
    await message.channel.send(`👤 **${user?.tag} joined at:** ${member?.joinedAt?.toDateString() || "N/A"}`);
    return;
  }

  if (command === "sysinfo") {
    await message.delete();
    await message.channel.send(`🌡️ **System Info:**\n**Platform:** ${process.platform}\n**Arch:** ${process.arch}\n**Node:** ${process.version}`);
    return;
  }

  if (command === "neko") {
    await message.delete();
    const res = await axios.get("https://nekos.life/api/v2/img/neko");
    await message.channel.send(res.data.url);
    return;
  }

  if (command === "psrv") {
    await message.delete();
    await message.channel.send("🏗️ **Applying backup...** (Stub)");
    return;
  }

  if (command === "downloadm") {
    await message.delete();
    const url = args[0];
    await message.channel.send(`📥 **Downloading:** ${url} (Requires downloader logic)`);
    return;
  }

  if (command === "ghost") {
    await message.delete();
    const user = message.mentions.users.first();
    if (!user) return;
    const m = await message.channel.send(`<@${user.id}>`);
    await m.delete();
    return;
  }

  if (command === "faketyping") {
    await message.delete();
    const sec = parseInt(args[0]) || 10;
    message.channel.sendTyping();
    return;
  }

  if (command === "invmsg") {
    await message.delete();
    const text = args.join(" ");
    await message.channel.send(`||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​|| ${text}`);
    return;
  }

  if (command === "nitrofake") {
    await message.delete();
    await message.channel.send("https://discord.gift/fake-nitro-code-troll");
    return;
  }

});

client.login(token);
