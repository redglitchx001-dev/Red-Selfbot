import React, { useState, useEffect, useRef } from "react";
import { 
  Shield, 
  Bot, 
  Terminal, 
  Plus, 
  Trash2, 
  Play, 
  Square, 
  Cpu, 
  Zap, 
  Ghost, 
  Image as ImageIcon, 
  Music, 
  Settings,
  AlertCircle
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { io, Socket } from "socket.io-client";

interface Token {
  id: string;
  name: string;
  token: string;
}

export default function App() {
  const [tokens, setTokens] = useState<Token[]>([]);
  const [newToken, setNewToken] = useState("");
  const [newName, setNewName] = useState("");
  const [logs, setLogs] = useState<string[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [activeTokenId, setActiveTokenId] = useState<string | null>(null);
  const [socket, setSocket] = useState<Socket | null>(null);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchTokens();
    checkBotStatus();

    const newSocket = io();
    setSocket(newSocket);

    newSocket.on("bot-log", (log: string) => {
      setLogs((prev) => [...prev.slice(-100), log]);
    });

    newSocket.on("bot-status", (status: { running: boolean }) => {
      setIsRunning(status.running);
    });

    return () => {
      newSocket.disconnect();
    };
  }, []);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  const fetchTokens = async () => {
    const res = await fetch("/api/tokens");
    const data = await res.json();
    setTokens(data);
  };

  const checkBotStatus = async () => {
    const res = await fetch("/api/bot/status");
    const data = await res.json();
    setIsRunning(data.running);
  };

  const addToken = async () => {
    if (!newToken || !newName) return;
    await fetch("/api/tokens", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: newToken, name: newName }),
    });
    setNewToken("");
    setNewName("");
    fetchTokens();
  };

  const deleteToken = async (id: string) => {
    await fetch(`/api/tokens/${id}`, { method: "DELETE" });
    fetchTokens();
  };

  const startBot = async (tokenId: string) => {
    setActiveTokenId(tokenId);
    setLogs([]);
    await fetch("/api/bot/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tokenId }),
    });
  };

  const stopBot = async () => {
    await fetch("/api/bot/stop", { method: "POST" });
    setActiveTokenId(null);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-200 font-sans selection:bg-red-500/30">
      {/* Header */}
      <header className="border-b border-neutral-800 bg-neutral-900/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-600 rounded-xl flex items-center justify-center shadow-lg shadow-red-900/20">
              <Shield className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-xl tracking-tight text-white">REDGLITCH</h1>
              <p className="text-xs text-neutral-500 font-mono">v2.0.0-BETA</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${isRunning ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
              <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
              {isRunning ? 'SYSTEM ONLINE' : 'SYSTEM OFFLINE'}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Management */}
        <div className="lg:col-span-4 space-y-6">
          {/* Add Token Section */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-5 border-b border-neutral-800 bg-neutral-800/30 flex items-center justify-between">
              <h2 className="font-semibold flex items-center gap-2">
                <Plus className="w-4 h-4 text-red-500" />
                Add Account
              </h2>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs font-mono text-neutral-500 uppercase mb-1.5 block">Alias Name</label>
                <input 
                  type="text" 
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Main Account"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-red-500/50 transition-colors"
                />
              </div>
              <div>
                <label className="text-xs font-mono text-neutral-500 uppercase mb-1.5 block">Discord Token</label>
                <input 
                  type="password" 
                  value={newToken}
                  onChange={(e) => setNewToken(e.target.value)}
                  placeholder="Mjk..."
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-red-500/50 transition-colors"
                />
              </div>
              <button 
                onClick={addToken}
                className="w-full bg-red-600 hover:bg-red-500 text-white font-semibold py-2.5 rounded-lg transition-all active:scale-95 shadow-lg shadow-red-900/20"
              >
                Register Token
              </button>
            </div>
          </section>

          {/* Accounts List */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-5 border-b border-neutral-800 bg-neutral-800/30">
              <h2 className="font-semibold flex items-center gap-2">
                <Bot className="w-4 h-4 text-red-500" />
                Active Accounts
              </h2>
            </div>
            <div className="divide-y divide-neutral-800">
              {tokens.length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-sm text-neutral-500 italic">No accounts registered.</p>
                </div>
              ) : (
                tokens.map((t) => (
                  <div key={t.id} className="p-4 flex items-center justify-between group hover:bg-neutral-800/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-neutral-800 flex items-center justify-center">
                        <Bot className="w-4 h-4 text-neutral-400" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">{t.name}</p>
                        <p className="text-[10px] font-mono text-neutral-500">ID: {t.id}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {isRunning && activeTokenId === t.id ? (
                        <button 
                          onClick={stopBot}
                          className="p-2 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                          title="Stop Bot"
                        >
                          <Square className="w-4 h-4 fill-current" />
                        </button>
                      ) : (
                        <button 
                          onClick={() => startBot(t.id)}
                          disabled={isRunning}
                          className="p-2 text-green-400 hover:bg-green-500/10 rounded-lg transition-colors disabled:opacity-30"
                          title="Start Bot"
                        >
                          <Play className="w-4 h-4 fill-current" />
                        </button>
                      )}
                      <button 
                        onClick={() => deleteToken(t.id)}
                        className="p-2 text-neutral-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                        title="Delete Account"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>
        </div>

        {/* Right Column: Console & Info */}
        <div className="lg:col-span-8 space-y-6">
          {/* Console */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl flex flex-col h-[600px]">
            <div className="p-4 border-b border-neutral-800 bg-neutral-800/30 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-red-500" />
                <h2 className="font-semibold text-sm">System Terminal</h2>
              </div>
              <div className="flex gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-neutral-700" />
                <div className="w-2.5 h-2.5 rounded-full bg-neutral-700" />
                <div className="w-2.5 h-2.5 rounded-full bg-neutral-700" />
              </div>
            </div>
            <div className="flex-1 p-4 font-mono text-xs overflow-y-auto bg-black/50 scrollbar-thin scrollbar-thumb-neutral-800">
              {logs.length === 0 ? (
                <div className="h-full flex items-center justify-center text-neutral-600 italic">
                  Waiting for system initialization...
                </div>
              ) : (
                logs.map((log, i) => (
                  <div key={i} className="mb-1 animate-in fade-in slide-in-from-left-2 duration-300">
                    <span className="text-neutral-500 mr-2">[{new Date().toLocaleTimeString()}]</span>
                    <span className={log.startsWith('ERROR') ? 'text-red-400' : 'text-neutral-300'}>{log}</span>
                  </div>
                ))
              )}
              <div ref={logEndRef} />
            </div>
          </section>

          {/* Quick Info Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <InfoCard icon={<Cpu />} label="CPU Usage" value="1.2%" color="text-blue-400" />
            <InfoCard icon={<Zap />} label="Latency" value="24ms" color="text-yellow-400" />
            <InfoCard icon={<Ghost />} label="Stealth" value="Active" color="text-purple-400" />
            <InfoCard icon={<AlertCircle />} label="Warnings" value="0" color="text-green-400" />
          </div>
        </div>
      </main>

      {/* Footer / Features */}
      <footer className="max-w-7xl mx-auto px-4 py-12 border-t border-neutral-900">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Feature icon={<Bot />} title="AI Intelligence" desc="Powered by Google Gemini for advanced conversations and image generation." />
          <Feature icon={<Shield />} title="Elite Moderation" desc="Complete suite of server management and protection tools." />
          <Feature icon={<Terminal />} title="Extreme Tier" desc="High-performance spam and raid capabilities for advanced users." />
        </div>
        <div className="mt-12 text-center text-neutral-600 text-xs font-mono">
          &copy; 2026 REDGLITCH PROJECT. ALL RIGHTS RESERVED.
        </div>
      </footer>
    </div>
  );
}

function InfoCard({ icon, label, value, color }: { icon: React.ReactNode, label: string, value: string, color: string }) {
  return (
    <div className="bg-neutral-900 border border-neutral-800 p-4 rounded-xl">
      <div className={`mb-2 ${color}`}>{React.cloneElement(icon as React.ReactElement, { className: "w-5 h-5" })}</div>
      <p className="text-[10px] font-mono text-neutral-500 uppercase tracking-wider">{label}</p>
      <p className="text-lg font-bold text-white">{value}</p>
    </div>
  );
}

function Feature({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="space-y-3">
      <div className="w-10 h-10 bg-neutral-900 border border-neutral-800 rounded-lg flex items-center justify-center text-red-500">
        {React.cloneElement(icon as React.ReactElement, { className: "w-5 h-5" })}
      </div>
      <h3 className="font-bold text-white">{title}</h3>
      <p className="text-sm text-neutral-500 leading-relaxed">{desc}</p>
    </div>
  );
}
