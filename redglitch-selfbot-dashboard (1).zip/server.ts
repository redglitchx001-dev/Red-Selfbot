import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import { spawn, ChildProcess } from "child_process";
import fs from "fs";

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer);
  const PORT = 3000;

  app.use(express.json());

  let botProcess: ChildProcess | null = null;
  const TOKENS_FILE = path.join(process.cwd(), "tokens.json");

  // Ensure tokens file exists
  if (!fs.existsSync(TOKENS_FILE)) {
    fs.writeFileSync(TOKENS_FILE, JSON.stringify([]));
  }

  app.get("/api/tokens", (req, res) => {
    const tokens = JSON.parse(fs.readFileSync(TOKENS_FILE, "utf-8"));
    res.json(tokens);
  });

  app.post("/api/tokens", (req, res) => {
    const { token, name } = req.body;
    const tokens = JSON.parse(fs.readFileSync(TOKENS_FILE, "utf-8"));
    tokens.push({ token, name, id: Date.now().toString() });
    fs.writeFileSync(TOKENS_FILE, JSON.stringify(tokens));
    res.json({ success: true });
  });

  app.delete("/api/tokens/:id", (req, res) => {
    const { id } = req.params;
    let tokens = JSON.parse(fs.readFileSync(TOKENS_FILE, "utf-8"));
    tokens = tokens.filter((t: any) => t.id !== id);
    fs.writeFileSync(TOKENS_FILE, JSON.stringify(tokens));
    res.json({ success: true });
  });

  app.post("/api/bot/start", (req, res) => {
    const { tokenId } = req.body;
    const tokens = JSON.parse(fs.readFileSync(TOKENS_FILE, "utf-8"));
    const tokenData = tokens.find((t: any) => t.id === tokenId);

    if (!tokenData) {
      return res.status(404).json({ error: "Token not found" });
    }

    if (botProcess) {
      botProcess.kill();
    }

    // Start Python bot
    botProcess = spawn("python3", ["bot.py", tokenData.token], {
      env: { ...process.env, GEMINI_API_KEY: process.env.GEMINI_API_KEY },
    });

    botProcess.stdout?.on("data", (data) => {
      io.emit("bot-log", data.toString());
    });

    botProcess.stderr?.on("data", (data) => {
      io.emit("bot-log", `ERROR: ${data.toString()}`);
    });

    botProcess.on("close", (code) => {
      io.emit("bot-status", { running: false, code });
      botProcess = null;
    });

    io.emit("bot-status", { running: true });
    res.json({ success: true });
  });

  app.post("/api/bot/stop", (req, res) => {
    if (botProcess) {
      botProcess.kill();
      botProcess = null;
      io.emit("bot-status", { running: false });
      res.json({ success: true });
    } else {
      res.json({ success: false, message: "Bot not running" });
    }
  });

  app.get("/api/bot/status", (req, res) => {
    res.json({ running: !!botProcess });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
